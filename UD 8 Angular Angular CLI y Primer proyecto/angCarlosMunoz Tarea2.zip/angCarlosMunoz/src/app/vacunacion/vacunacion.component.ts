import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vacunacion',
  templateUrl: './vacunacion.component.html',
  styleUrls: ['./vacunacion.component.css']
})
export class VacunacionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
